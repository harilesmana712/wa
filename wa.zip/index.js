const { makeWASocket, DisconnectReason, useMultiFileAuthState, MessageType } = require('@whiskeysockets/baileys');
const fs = require('fs-extra');
const fetch = require('node-fetch');
const { handleAnimeSearch } = require('./lib/fun/whatanim');
const cheerio = require('cheerio');
  const { handleDemote } = require('./lib/admin/demote');
 const { handlePromote } = require('./lib/admin/promote');
const { handleHidetag } = require('./lib/admin/hidetag');
const { handleKick } = require('./lib/admin/kick'); 
const { handleMenu, handleToramMenu, handleSpotFarmMenu, handleAdminMenu, handleDownloadMenu,handleHaveFunMenu } = require('./lib/menu');
const { handleBufflandMenu, handleBufflandDetail } = require('./lib/toram/buff');
const { handleRngCommand } = require('./lib/fun/rng');
const { handleRlCommand } = require('./lib/fun/loli');
const { handleLvling } = require('./lib/toram/leveling');
const { handleSpotFarmDetails } = require('./lib/toram/sfarm');
const { handleBMQ } = require('./lib/toram/bmq');
const { handlePadu } = require('./lib/toram/padu');
const { handleLBS } = require('./lib/toram/lbs');
const { handleLPT } = require('./lib/toram/lpt');
const { handleSlotCommand } = require('./lib/toram/slot');
const { handlePaggCommand } = require('./lib/toram/pagg');
const { handleTagAllCommand } = require('./lib/admin/tagall');
const { handleListPanah } = require('./lib/toram/listpanah');
const { handleMt } = require('./lib/toram/mt');// Pastikan path sesuai
const { handleHokiCommand} = require('./lib/fun/hoki'); // Pain path sesuai
const { handlePedoCommand } = require('./lib/fun/pedo'); // Pastikan path sesuai

const prefixes = ['.', '!', '#', '*', '%', '&'];

function getPrefix(message) {
    for (const prefix of prefixes) {
        if (message.startsWith(prefix)) {
            return prefix;
        }
    }
    return null;
}

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');

    const conn = makeWASocket({
        auth: state,
        printQRInTerminal: true, // Print QR code in terminal
        qrTimeout: 60 * 60 * 24 * 365 // Set QR code timeout to 1 year
    });

    conn.ev.on('creds.update', saveCreds);

    conn.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            console.log('QR code:', qr);
        }

        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect.error)?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log('connection closed due to ', lastDisconnect.error, ', reconnecting ', shouldReconnect);
            if (shouldReconnect) {
                connectToWhatsApp();
            }
        } else if (connection === 'open') {
            console.log('opened connection');
        }
    });


    // Event listener for incoming messages

    conn.ev.on('messages.upsert', async (m) => {
        const message = m.messages[0];
        if (!message.message || message.key.fromMe) return;

        const content = message.message.conversation || message.message.extendedTextMessage?.text;
        if (!content) return;

        const prefix = getPrefix(content);
        if (prefix) {
            const command = content.slice(prefix.length).trim().split(/\s+/)[0].toLowerCase();
            const args = content.slice(prefix.length + command.length).trim().split(/\s+/);

            switch (command) {
                case 'sfarm':
                    await handleSpotFarmMenu(conn, message);
                    break;
                
                case 'kayu':
                case 'kain':
                case 'obat':
                case 'metal':
                case 'fauna':
                case 'mana':
                    await handleSpotFarmDetails(conn, message, command);
                    break;
                    case 'whatanim':
                await handleAnimeSearch(conn, message);
                break;
                case 'tagall':
                    await handleTagAllCommand(conn, message, command, args);
                    break;

                case 'bmq':
                    await handleBMQ(conn, message);
                    break;
case 'mt':
    await handleMt(conn, message);
    break;
                case 'slottas':
                    await handleSlotCommand(conn, message);
                    break;
                case 'hoki':
                    await handleHokiCommand(conn, message);
                    break;
                case 'pedo':
                    await handlePedoCommand(conn, message);
                    break;

         case 'promote':
    await handlePromote(conn, message);
    break;
         case 'demote':
    await handleDemote(conn, message);
    break;
case 'hidetag':
    await handleHidetag(conn, message, args);
    break;
                case 'kick':
                    await handleKick(conn, message);
                    break;

                case 'pagg':
                    await handlePaggCommand(conn, message);
                    break;

                case 'adm':
                    await handleAdminMenu(conn, message);
                    break;

                case 'menu':
                    await handleMenu(conn, message);
                    break;

                case 'toram':
                    await handleToramMenu(conn, message);
                    break;
                case 'dload':
                    await handleDownloadMenu(conn, message);
                    break;
                case 'hfun':
                    await handleHaveFunMenu(conn, message);
                    break;

                case 'buffland':
                    await handleBufflandMenu(conn, message);
                    break;

                case 'padu':
                    await handlePadu(conn, message);
                    break;

                case 'lbs':
                    await handleLBS(conn, message);
                    break;

                case 'lpt':
                    await handleLPT(conn, message);
                    break;
                case 'rng':
    await handleRngCommand(conn, message);
    break;
                case 'loli':
    await handleRlCommand(conn, message);
    break;

                case 'listpanah':
                    await handleListPanah(conn, message);
                    break;

                case 'agi':
                case 'str':
                case 'dex':
                case 'vit':
                case 'int':
                case 'acc':
                case 'dodge':
                case 'def':
                case 'mdef':
                case 'matk':
                case 'watk':
                case 'atk':
                case 'mres':
                case 'pres':
                case 'dte':
                case 'xpgain':
                case 'droprate':
                case 'cr':
                case 'ampr':
                case '+aggro':
                case '-aggro':
                case 'mp':
                case 'hp':
                    await handleBufflandDetail(conn, message, command);
                    break;

                default:
                    if (/^lvling\d+$/.test(command)) {
                        await handleLvling(conn, message, command);
                    }
                    else {
                        await conn.sendMessage(message.key.remoteJid, { text: 'Perintah tidak dikenali. Ketik !menu untuk daftar perintah.' }, { quoted: message });
                    }
                    break;
            }
        }
    });
}

// Start the WhatsApp connection
connectToWhatsApp(); 